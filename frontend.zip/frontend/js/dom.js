// ==========================================
// DOM ELEMENTS
// ==========================================

const historicalViewNotice = document.getElementById("historical-view-notice");

// Tabs and pannels

 
const tabs = {
    quantitative: {
        tab: document.getElementById("quantitative-tab"),
        panel: document.getElementById("quantitative-panel")
    },
    qualitative: {
        tab: document.getElementById("qualitative-tab"),
        panel: document.getElementById("qualitative-panel")
    }, 
    valuation: {
        tab: document.getElementById("valuation-tab"),
        panel: document.getElementById("valuation-panel")
    }
};


// Search and analysis
const searchForm = document.querySelector("#search-form");
const tickerInput = document.querySelector("#ticker-input");
const analyzeButton = document.querySelector("#analyze-button");
const welcomeMessage = document.querySelector("#welcome-message");
const statusMessage = document.querySelector("#status-message");

//Quantitative analysis
const refreshFinancials = document.querySelector("#refresh-financials");
const analysisContent = document.querySelector("#analysis-content");
const historicalCharts = {};
const FiveYearPriceChart = document.querySelector("#five-year-price-chart");
const OneYearPriceChart = document.querySelector("#one-year-price-chart");


// Watchlist
const watchlistCompanies = document.querySelector("#watchlist-companies");
const watchlistEmpty = document.querySelector(".watchlist-empty");
const watchlistElement = document.querySelector(".watchlist-item");
const watchlistHeader = document.querySelector(".watchlist-header");
const watchlistAdd = document.getElementById("watchlist-add");

//Watchlist comparing mode
const compareSelectButton = document.getElementById("compare-analyses")
const compareSelectionCount = document.getElementById("omparison-selection-count")
const comparisonInstructions = document.getElementById("comparison-instructions")
const comparisonSelectionCount = document.getElementById("comparison-selection-count")

// Normal and comparison mode
const normalView = document.getElementById("normal-dashboard-view")
const comparisonView = document.getElementById("comparison-view")

// Comparison view
const exitComparisonButton = document.getElementById("exit-comparison")

// Watchlist controls in the analysis
const saveCompany = document.querySelector("#save_watchlist");
const watchlistActions = document.querySelector("#watchlist-actions");
const updateCompany = document.querySelector("#update_analysis");

// Analysis update modal
const updateAnalysisModal = document.querySelector("#analysis-update-modal")
const updateCurrentVersionButton = document.querySelector("#update-current-analysis")
const saveNewVersion = document.querySelector("#new-analysis-version")
const closeUpdateModal = document.querySelector("#close-analysis-update-modal")
const saveSelection = document.querySelector("#save-selection")
const saveSuccess = document.querySelector("#save-success")
const closeSaveSuccess = document.querySelector("#close-save-success")

// Unsaved changes modal
const unsavedChangesModal = document.querySelector("#unsaved-changes-modal");
const navigationUpdateButton = document.querySelector("#navigation-update-analysis");
const navigationNewButton = document.querySelector("#navigation-new-analysis");
const cancelNavigationButton = document.querySelector("#cancel-navigation");
const discardAndContinueButton = document.querySelector("#discard-and-continue");
const continueAfterSaveButton = document.querySelector("#continue-after-save");

// Auth modal 
const authModal = document.querySelector("#auth-modal")
const authForm = document.querySelector("#auth-form")
const authSubmit = document.querySelector("#auth-submit")
const authEmail = document.querySelector("#auth-email")
const authPassword = document.querySelector("#auth-password")
const authError = document.querySelector("#auth-error")
const authToggle = document.querySelector("#auth-toggle")
const authTitle = document.querySelector("#auth-title")
const authDescription = document.querySelector("#auth-description")
const authClose = document.querySelector("#auth-close");


// Account modal
const accountButton = document.querySelector("#account-button")
const accountModal = document.querySelector("#account-modal")
const accountModalContent = document.querySelector("#account-modal .account-modal");
const closeAccountModal = document.querySelector("#close-account-modal")
const accountMenu = document.querySelector("#account-menu")

const changePasswordForm = document.querySelector("#change-password-form");
const changePasswordButton = document.querySelector("#change-password-button")
const changePasswordView = document.querySelector("#change-password-view")
const closePasswordView = document.querySelector("#close-password-view")
const newPassword = document.querySelector("#new-password")
const confirmNewPassword = document.querySelector("#confirm-password")
const saveNewPassword = document.querySelector("#save-password-button")
const passwordError = document.querySelector("#password-error")
const passwordSuccess = document.querySelector("#password-success")

const signOutButton = document.querySelector("#sign-out-button")
const signoutFeedback = document.querySelector("#account-feedback")

const deleteAccountButton = document.querySelector("#delete-account-button");
const deleteAccountView = document.querySelector("#delete-account-view");
const confirmDeleteAccount = document.querySelector("#confirm-delete-account");
const cancelDeleteAccount = document.querySelector("#cancel-delete-account");
const closeDeleteAccountView = document.querySelector("#close-delete-account-view");
const deleteAccountError = document.querySelector("#delete-account-error");



// Metric info buttons
const metricInfoButtons = document.querySelectorAll(".metric-info");

const metricInfoOverlay = document.querySelector("#metric-info-overlay");
const metricInfoModal = document.querySelector("#metric-info-modal");
const metricInfoTitle = document.querySelector("#metric-info-title");
const metricInfoContent = document.querySelector("#metric-info-content");
const closeMetricInfoButton = document.querySelector("#close-metric-info");


// DCF
const dcfScenarioButtons = document.querySelectorAll(".dcf-scenario");
let dcfForecastChart = null;

// Loading overlay
const overlay = document.getElementById("loadingOverlay");
